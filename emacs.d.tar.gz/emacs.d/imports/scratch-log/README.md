scratch-log とは
=============

emacs の *scratch* バッファのログを取ります。*scratch* バッファを削除できなくします。機能と設定方法は、http://d.hatena.ne.jp/kitokitoki/20100612/p1 に書きました。
