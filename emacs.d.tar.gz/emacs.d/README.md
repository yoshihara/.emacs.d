# .emacs.d

emacs configuration

## Setup

```
  $ mv ~/
  $ git clone https://github.com/yoshihara/.emacs.d.git
```

## configurations

* 00: globalな設定、キーバインド
* 10: 設定で使う便利関数
* 20: packages.el / el-get
* 30: packages.elでいれたもののせってい
* 40: importsにあるもののせってい
* 50: 自分で入れたものの設定
* 60: 最初から入ってるものの設定
* 70: emacs使う上での便利コマンド

